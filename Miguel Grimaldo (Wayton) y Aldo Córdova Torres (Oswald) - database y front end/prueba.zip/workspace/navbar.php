
<table>
    <tr>
        <td>Home Page</td>
        <td>About me</td>
    </tr>
</table>