
<?php
include_once 'navbar.php';
?>    

<form action="result.php" target="_blank">
<select>
  <option value="monterrey">monterrey</option>
  <option value="san_pedro">san pedro</option>
  <option value="guadalupe">guadalupe</option>
  <option value="monclova">monclova</option>
  <option value="guadalajara">guadalajara</option>
</select>
    <input type="submit" name=""/>
</form>